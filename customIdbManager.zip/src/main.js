import WebLoG  from "./lib/idbmanager";

export var WebLog = WebLoG;
export default WebLoG;